<?php $__env->startSection('content'); ?>

<head>
    <link href="/css/user.css" rel="stylesheet">
</head>
<?php $__env->startSection('content'); ?>
<section class="section-projects-admin py-2 text-xs-center">
    <div class="fondo">
        <?php echo $__env->make('layouts.partials._navigationBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container container-projects-admin">
            <div class="row table-responsive text-center projects-table">
                <h1 class="text-center">LISTA DE USUARIOS</h1>

                <?php if(Auth::user()->hasAnyRole(['Administrador'])): ?>
                    <div class="offset-md-8 col-md-4 text-right">
                        <a data-toggle="modal" data-target="#createUser">
                            <button id="btnUser" type="button" class="btn btn-dark">
                                Crear nuevo usuario &nbsp;&nbsp;<i class="fas fa-plus"></i>
                            </button>
                        </a>
                    </div>
                <?php endif; ?>

                <br>
                <table class="table text-center table-sm-responsive" id="tableUsers">
                    <thead style="background-color: #252b37">
                        <tr>
                            <th> Id</th>
                            <th> Tipo</th>
                            <th> Codigo</th>
                            <th> Nombre</th>
                            <th> E-mail</th>
                            <th> Telefono</th>
                            <th class="col-md-3"> Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <?php if(is_null($user->code)): ?>
                                <td>EMPLEADO</td>
                            <?php else: ?>
                                <td>CLIENTE</td>
                            <?php endif; ?>
                            <td><?php echo e($user->code); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <?php if(count($user->contacts)>0): ?>
                                <td><?php echo e($user->contacts[0]->cellphone); ?></td>
                            <?php else: ?>
                                <td>Sin teléfono</td>
                            <?php endif; ?>
                            <td>
                                <?php if(Auth::user()->hasAnyRole(['Administrador'])): ?>
                                    <a data-toggle="modal" data-target="#editUser">
                                        <button type="button" class="btn btn-primary" title="Editar Usuario" onclick="openModalEditUser(<?php echo e($user); ?>)"><i class="fas fa-edit"></i></button>
                                    </a>
                                <?php else: ?>
                                    ..........
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No hay datos</p>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php echo $__env->make('admin/users/create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin/users/edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/admin/users/users.blade.php ENDPATH**/ ?>