<div class="modal fade" id="idModalGallery">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="idFolio"><span class="fa fa-spinner" aria-hidden="true"></span>&nbsp;&nbsp;<strong class="modal-folio">PROYECTO: </strong> <strong id='idFolioProjectGallery'></strong></h4>
                <button type="button" class="" data-dismiss="modal">&times;</button>
            </div>
            <div class="text-right modal-header-info">
                <h4 class=""><strong>GALERIA DE IMAGENES </strong></h4>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <div class="row">
                    </div>
                    <div>
                        <ul class="galeria">
                            <div class="row" style="justify-content: center">
                                <?php if($project->images->isEmpty()): ?>
                                <div class="alert text-center row" role="alert">
                                    <strong>No hay imagenes para mostrar</strong>
                                </div>
                                <?php endif; ?>
                                <?php $__currentLoopData = $project->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 text-center" style="margin-right:50px">
                                    <span  style="color: black">
                                        <span style="display: none"><?php echo e(setlocale(LC_TIME,'spanish')); ?></span>
                                        <?php echo e(strftime("%d de %B del %Y", strtotime(date("d M Y",strtotime($image->created_at))))); ?>

                                    </span>
                                    <li><a href="<?php echo e('#image'.explode('.', explode('_', $image->name)[1])[0]); ?>"><img src="<?php echo e(asset('storage/'.$image->path )); ?>"></a></li>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </ul>
                        <?php $__currentLoopData = $project->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <figure id="<?php echo e('image'.explode('.', explode('_', $image->name)[1])[0]); ?>" class="lbox bounce">
                            <span><a href="<?php echo e('#image'. ( intval( explode('.', explode('_', $image->name)[1])[0])-1)); ?>" title='Anterior'><i class="fas fa-angle-left"></i></a></span>
                            <img alt="" title="" src="<?php echo e(asset('storage/'.$image->path )); ?>" />
                            <span id='right'><a href="<?php echo e('#image'. ( intval( explode('.', explode('_', $image->name)[1])[0])+1)); ?>" title='Siguiente'><i class="fas fa-angle-right"></i></a></span>
                            <a title='Cerrar' href="#_"><i class="fas fa-times"></i></a>
                            <h2>
                                <span style="display: none"><?php echo e(setlocale(LC_TIME,'spanish')); ?></span>
                                <?php echo e(strftime("%d de %B del %Y", strtotime(date("d M Y",strtotime($image->created_at))))); ?>

                            </h2>
                        </figure>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="modal-footer " style="justify-content: center;">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/client/projects/advances/modals/images.blade.php ENDPATH**/ ?>