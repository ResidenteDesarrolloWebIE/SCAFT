<?php $__env->startSection('content'); ?>

<head>
    <link href="/css/agreements.css" rel="stylesheet">
</head>

<?php $__env->startSection('content'); ?>
<section class="section-projects-admin py-2 text-xs-center">
    <div class="fondo">
    <?php echo $__env->make('layouts.partials._navigationBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container container-projects-admin">
        <div class="row table-responsive text-center projects-table">
            <h1 class="text-center">LISTA DE ACUERDOS</h1>
            <div class="offset-md-8 col-md-4 text-right">
            <a href="/minutas/<?php echo e($minuta->project_id); ?>"><button id="btnProject" type="button" class="btn btn-dark" onclick="">
                    Ver minutas  <i class="fas fa-undo"></i>
                </button></a>
            </div>
            <br>
            <table class="table table-sm-responsive" id="tableAgreements">
                <thead class="table-success" style="background-color: #252b37">
                    <tr style="text-align:center">
                        <th>N°</th>
                        <th>Acuerdo</th>
                        <th>Responsable</th>
                        <th>Estatus</th>
                        <th style="width:100px">Fecha inicio</th>
                        <th style="width:100px">Fecha final</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $minuta->agreements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agreement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($agreement->agreement); ?></td>
                        <td><?php echo e($agreement->responsable); ?></td>
                        <td align="center"><?php echo e($agreement->status); ?></td>
                        <td align="center"><?php echo e($agreement->start_date); ?></td>
                        <td align="center"><?php echo e($agreement->end_date); ?></td>
                        <td align="center">
                        <button  data-toggle="modal" data-target="#modalEditAgreement" type="button" class="btn btn-primary"  title="Editar Acuerdo" onclick="openModalEditAgreement(<?php echo e($agreement); ?>)"><i class="fas fa-edit"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php echo $__env->make('admin/projects/modalEditAgreement', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/admin/projects/viewAgreements.blade.php ENDPATH**/ ?>