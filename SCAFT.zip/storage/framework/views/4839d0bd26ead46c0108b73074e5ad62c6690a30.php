<?php $__env->startSection('content'); ?>


<nav class="d-flex">
    <div class="p-2 w-100 " style="background-color:#19202C">
        <a  class="site-logo text-center">
            <img class="logo" src="<?php echo e(asset('images/logo1.png')); ?>" alt="">
        </a>
    </div>
    <div class="p- flex-shrink-1" style="background-color:#19202C;color:white">Pagina no encontrada</div>
</nav>

<div class="d-flex justify-content-center" style="min-height: 78vh; background: url('../images/fondo1.jpg');background-size: cover;overflow: hidden;">
    <div class="row" style="color: black;display: flex;align-items: center;justify-content: center;">
        <h1 class="text-center" style="background-color:white; opacity:70%;padding:30px"> ¡¡¡ERROR!!! <br> PAGINA NO ENCONTRADA</h1>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/errors/404.blade.php ENDPATH**/ ?>