<!DOCTYPE html>
<html lang="zxx">
    <?php echo $__env->make('layouts.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body onload="window.history.forward();">
        <?php echo $__env->yieldContent('content'); ?>
    </body>
    <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/layouts/app.blade.php ENDPATH**/ ?>