<?php $__env->startSection('content'); ?>

<section class="section-home">
	<?php echo $__env->make('layouts.partials._navigationBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="container-home">
		<?php if(Auth::user()->hasRole('Cliente')): ?>
			<div class="testimotionals col-md-3 col-sm-5">
				<div class="card">
					<div class="layer"></div>
					<div class="content">
						<p>Tableros TPCYM, Servicio de pruebas en fábrica para TPCYM´S, Elaboración de ingeniería para TPCYM´S.</p>
						<div class="image">
							<img width="100px" src="<?php echo e(asset('images/supply-home.png')); ?>" alt="">
						</div>
						<div class="details">
							<h2><br>
								<a href="<?php echo e(url('/projects/supplies')); ?>"> <span class="btn">SUMINISTROS</span></a>
							</h2>
						</div>
					</div>
				</div>
			</div>

			<div class="testimotionals col-md-3 col-sm-5">
				<div class="card">
					<div class="layer"></div>
					<div class="content">
						<p>Servicio de integración al sistema existente, Actualización de esquemas, Instalación de redes de comunicación.</p>
						<div class="image">
							<img width="100px" src="<?php echo e(asset('images/service-home.png')); ?>" alt="">
						</div>
						<div class="details">
							<h2>
								<br><a href="<?php echo e(url('/projects/services')); ?>"> <span class="btn">SERVICIOS</span></a>
							</h2>
						</div>
					</div>
				</div>
			</div>
		<?php elseif((Auth::user()->hasAnyRole(['Administrador','Ofertas','Ventas','Ingenieria','Manufactura','Servicio','Almacen','Finanzas', 'Lider', 'Consulta']))): ?>
			<div class="testimotionals col-md-5 col-sm-5">
				<div class="card">
					<div class="layer"></div>
					<div class="content">
						<p>SERVICIOS: Servicio de integración al sistema existente, Actualización de esquemas, Instalación de redes de comunicación.</p>
						<p>SUMINISTROS: Tableros TPCYM, Servicio de pruebas en fábrica para TPCYM´S, Elaboración de ingeniería para TPCYM´S.</p>
						<div class="image">
							<img width="100px" src="<?php echo e(asset('images/supply-home.png')); ?>" alt="">
						</div>
						<div class="details">
							<h2><br>
								<a href="<?php echo e(url('/projects')); ?>"> <span class="btn">Lista de proyectos</span></a>
							</h2>
						</div>
					</div>
				</div>
			</div>
		<?php else: ?>
			<div class="testimotionals col-md-5 col-sm-5">
				<div class="card">
					<div class="layer"></div>
					<div class="content">
						<h2>El rol asignado no existe</h2>
						<div class="image">
							<img width="100px" src="<?php echo e(asset('images/supply-home.png')); ?>" alt="">
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/home.blade.php ENDPATH**/ ?>