<?php $__env->startSection('content'); ?>

<head>
    <link href="/css/minutes.css" rel="stylesheet">
</head>

<?php $__env->startSection('content'); ?>
<section class="section-projects-admin py-2 text-xs-center">
    <div class="fondo">
        <?php echo $__env->make('layouts.partials._navigationBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container container-projects-admin">
            <div class="row table-responsive text-center projects-table">
                <h1 class="text-center">LISTA DE MINUTAS</h1>
                <?php if( (Auth::user()->hasRole('Lider') && Auth::user()->hasRole('Ventas')) || Auth::user()->hasAnyRole(['Administrador','Ofertas'])): ?>
                <div class="offset-md-8 col-md-4 text-right">
                    <button id="btnProject" type="button" class="btn btn-dark" onclick="openModalAddMinute(<?php echo e($project); ?>)">
                        Agregar Minuta <i class="fas fa-plus"></i>
                    </button>
                    <a href="/projects"><button id="btnProject" type="button" class="btn btn-dark">
                            Ver proyectos <i class="fas fa-undo"></i>
                        </button></a>
                </div>
                <?php endif; ?>
                <br>
                <table class="table text-center table-sm-responsive" id="tableMinutes">
                    <thead class="table-success" style="background-color: #252b37">
                        <tr>
                            <th>Folio</th>
                            <th>Tipo</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $minutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $minute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($minute->folio); ?></td>
                            <td><?php echo e($minute->type); ?></td>
                            <td>
                                <button data-toggle="modal" data-target="#modalAgreements" type="button" class="btn btn-primary" title="Listar acuerdos" onclick="getAgreements(<?php echo e($minute->id); ?>)"><i class="fas fa-eye"></i></button>
                                <a href="/exportMinute/<?php echo e($minute->id); ?>"><button type="button" class="btn btn-dark" title="Descargar PDF"><i class="fas fa-file-alt"></i></button></a>

                                <?php if( ( $minute->type == "EXTERNA" && (Auth::user()->hasRole('Lider') && Auth::user()->hasRole('Ventas')) ) || Auth::user()->hasRole('Administrador')): ?>
                                    <a href="/agreements/<?php echo e($minute->id); ?>"><button type="button" class="btn btn-primary" title="Ver acuerdos"><i class="fas fa-external-link-alt"></i></button></a>
                                <?php elseif( ($minute->type == "INTERNA" && Auth::user()->hasRole('Ofertas')) || Auth::user()->hasRole('Administrador')): ?>
                                    <a href="/agreements/<?php echo e($minute->id); ?>"><button type="button" class="btn btn-primary" title="Ver acuerdos"><i class="fas fa-external-link-alt"></i></button></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php echo $__env->make('admin/projects/createMinuta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin/projects/modalAgreements', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/admin/projects/viewMinutes.blade.php ENDPATH**/ ?>