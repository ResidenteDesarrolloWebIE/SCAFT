<!doctype html>

<head>
    <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta charset="utf-8">

    <title><?php echo e(config('app.name', 'SCATF')); ?></title>
    <link href="images/icon.ico" rel="shortcut icon" />

    <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-5.12.1/css/fontawesome.css')); ?>">
    <link href="<?php echo e(asset('css/auth/login.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap-4.4.1/css/bootstrap.min.css')); ?>">

    <script src="<?php echo e(asset('plugins/fontawesome-5.12.1/fontawesome.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/jquery-3.4.1/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/auth/login.js')); ?>"></script>
</head>

<body class="login-background" >
    <div class="container">
        <div class="row login-text-center">
            <div class="col-xs-8 col-sm-6 col-md-5">
                <div class="card" id="card1">

                    <div class="card-header text-center" style="background-color:#DEDBDB">
                        <h4><?php echo e(__('BIENVENIDO')); ?></h4>
                        <img class="login-image" src="<?php echo e(asset('images/logo-login.png')); ?>" class="card-img-top">
                    </div>

                    <div class="card-body" style="background-color:#DEDBDB">
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <div class="input-group ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="background-color:#3982ab" id="basic-addon1">
                                            <i class="fas fa-user" style='color:white'></i></span>
                                    </div>
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Correo electrónico"> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback text-center" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="input-group ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text login-icon-color" id="pass" style="background-color:#3982ab"><i class="fas fa-key" style='color:white'></i></span>
                                    </div>
                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Contraseña">

                                    <div class="input-group-append">
                                        <span class="input-group-text" onclick="showPassword()" style="background-color:#3982ab"><i class="fas fa-eye" style='color:white'></i></span>
                                    </div>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback text-center" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row">
                                <!-- form-group  -->
                                <div class="col offset-md-1" style="margin-top:10px">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old( 'remember') ? 'checked' : ''); ?>>
                                        <label class="form-check-label" style="background-colorcolor: blue" for="remember">
                                            <strong><?php echo e(__('Recordar contraseña')); ?></strong>
                                        </label>
                                    </div>
                                </div><br><br>
                            </div>

                            <br>
                            <div class=" row text-center">
                                <div class="col offset-md-1">
                                    <button type="submit" class="login-btn"><?php echo e(__('Iniciar sesión')); ?></button>
                                </div>
                            </div>
                            <div class=" row text-center" style="margin-top:12px">
                                <div class="col offset-md-1">
                                    <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <strong><?php echo e(__('¿Olvidaste tu contraseña?')); ?></strong>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/auth/login.blade.php ENDPATH**/ ?>