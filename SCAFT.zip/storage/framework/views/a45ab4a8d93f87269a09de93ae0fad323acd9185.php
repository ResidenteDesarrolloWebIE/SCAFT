<div class="modal fade" id="createUser">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <span type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="tokenLoadImages"> </span>
            <div class="modal-header">
                <h4 class="modal-title" id="idFolio"><span class="fa fa-spinner" aria-hidden="true"></span>&nbsp;&nbsp;<strong class="modal-folio">CREAR NUEVO USUARIO</strong></h4>
                <button type="button" class="" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <?php echo e(Form::open(['method'=>'POST','id'=>'formCreateUser','enctype'=>'multipart/form-data', 'class'=>'row','onsubmit'=>'saveUser(this); return false;'])); ?>

                <input type="hidden" name="token" value="<?php echo e(csrf_token()); ?>" id="token" readonly="true" />

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group text-center">
                                <label for="typeUser"><strong style="color:red">*</strong><strong>Tipo de Usuario</strong></label>
                                <select class="custom-select" id="idTypeUser" name="typeUser" required>
                                    <option value="" selected disabled> Seleccionar un tipo</option>
                                    <option value="CLIENTE">CLIENTE</option>
                                    <option value="EMPLEADO">EMPLEADO</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group text-center">
                                <label for="codeUser"><strong style="color:red">*</strong><strong>Codigo</strong></label>
                                <input type="text" class="form-control" name="codeUser" id="codeUser" value="" disabled="true" onkeyup="javascript: this.value = this.value.toUpperCase();" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group text-center">
                                <label for="nameUser"><strong style="color:red">*</strong><strong>Nombre</strong></label>
                                <input type="text" class="form-control" name="nameUser" id="nameUser" value="" onkeyup="javascript: this.value = this.value.toUpperCase();" required>
                            </div>
                            <div class="form-group text-center">
                                <label for="emailUser"><strong style="color:red">*</strong><strong>E-mail</strong></label>
                                <input type="email" class="form-control" name="emailUser" id="emailUser" value="" required>
                            </div>
                            <div class="form-group text-center">
                                <label for="passwordUser"><strong style="color:red">*</strong><strong>Contraseña</strong></label>
                                <input type="text" class="form-control" name="passwordUser" id="passwordUser" value="" required>
                            </div>

                        </div>

                        <div class="col-md-6">
                            <div class="form-group text-center">
                                <label for="puestoUser"><strong style="color:red">*</strong><strong>Puesto</strong></label>
                                <input type="text" class="form-control" name="puestoUser" id="puestoUser" style="text-transform:uppercase;" onkeyup="javascript: this.value = this.value.toUpperCase();" value="" required>
                            </div>

                            <div class="form-group text-center">
                                <label for="cellUser"><strong style="color:red">*</strong><strong>Telefono</strong></label>
                                <input type="number" class="form-control" name="cellUser" id="cellUser" value="" required>
                            </div>

                            <!-- <label for="rolUser"><strong>Roles</strong></label>
                            <div class="custom-control custom-checkbox" id="allroles">
                                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <input type="checkbox" name="idRoles[]" value="<?php echo e($rol->id); ?>">
                                    <label for="<?php echo e($rol->id); ?>"><?php echo e($rol->name); ?></label>
                                    <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p>No hay datos</p>
                                <?php endif; ?>
                            </div>  -->
                            <div class="form-group text-center" id="allroles">
                                <label for="clientProject"><strong style="color:red">*</strong><strong>Roles</strong></label>
                                <select class="custom-select" name="roles[]" id="selectRolesUser" multiple> 
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($rol->id); ?>"><?php echo e($rol->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
            <div class="modal-footer " style="justify-content: center;">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary">Guardar</button><!-- type="button" onclick="save()" -->
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/admin/users/create.blade.php ENDPATH**/ ?>