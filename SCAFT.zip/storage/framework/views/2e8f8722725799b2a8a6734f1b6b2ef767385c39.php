<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    

    <title><?php echo e(config('app.name', 'SCATF')); ?></title>
    <link href="<?php echo e(asset('images/icon.ico')); ?>" rel="shortcut icon" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('css/auth/_navigationBar.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/projects.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/modals/images.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/client/clientGeneral.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/client/technicalAdvance.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/client/economicAdvance.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/client/gallery.css')); ?>" />
    

    <link rel="stylesheet" href="<?php echo e(asset('plugins/dropzone-2012/dropzone.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fileinput-4.3.6/css/fileinput.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fileinput-4.3.6/css/fileinput.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap-4.4.1/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap-4.4.1/css/bootstrap-multiselect.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/dataTables-1.10.20/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-5.12.1/css/solid.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fotoroma-4.6.4/fotorama.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/jquery-ui-1.12.1/jquery-ui.css')); ?>">
</head><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/layouts/partials/_header.blade.php ENDPATH**/ ?>