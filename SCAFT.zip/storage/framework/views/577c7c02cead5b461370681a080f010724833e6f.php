<?php $__env->startSection('content'); ?>

<section class="section-home">
	<?php echo $__env->make('layouts.partials._navigationBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- AVANCE TÉCNICO -->
	<div class="container">
		<div id="rectangulo" class="forma">
			<p>NOMBRE DEL PROYECTO: <span style="text-decoration:underline;"> <?php echo e($project->name); ?></span><br>
				CODIGO PROYECYO: <span style="text-decoration:underline;"> <?php echo e($project->folio); ?></span><br>
				CLIENTE: <span style="text-decoration:underline;"> <?php echo e($project->customer->name); ?></span><br>
				SUBESTACION: <span style="text-decoration:underline;"> <?php echo e($project->substation); ?></span><br>
				DESCRIPCION: <span style="text-decoration:underline;"> <?php echo e($project->description); ?></span><br>
			</p>
		</div>
		<div class="row text-center">
			<div class="col-md-2">
				<a data-toggle="modal" data-target="#idModalOffer"><button type="button" class="btn btn-dark btn-block" onclick='initializeModalsCustomers(<?php echo e($project); ?>)'>Oferta</button></a>
			</div>
			<div class="col-md-2">
				<a data-toggle="modal" data-target="#idModalPurchaseOrder"><button type="button" class="btn btn-dark btn-block" onclick='initializeModalsCustomers(<?php echo e($project); ?>)'>Orden de compra</button></a>
			</div>
			<div class="col-md-2">
				<a data-toggle="modal" data-target="#idModalMinutas"><button type="button" class="btn btn-dark btn-block" onclick='initializeModalsCustomers(<?php echo e($project); ?>)'>Minutas</button></a>
			</div>
			<div class="col-md-2">
				<a data-toggle="modal" data-target="#idModalGallery"><button type="button" class="btn btn-dark btn-block" onclick='initializeModalsCustomers(<?php echo e($project); ?>)'>Galeria</button></a>
			</div>
		</div>
		<!-- AVANCE TECNICO -->
		<div style="display:inline-block;width:100%;">
			<ul class="timeline timeline-horizontal">
				<li class="timeline-item">
					<button class="btn btn-sm btn-primary">AVANCE TÉCNICO</button>
				</li>
				<li class="timeline-item">
					<div class="timeline-badge primary">
						<b><?php echo e($project->technicalAdvances->receive_order); ?> %</b>
					</div>
					<p>
						<span id="lower-text">ORDEN DE<br>COMPRA</span>
					</p>
				</li>

				<li class="timeline-item">
					<div class="timeline-badge primary">
						<b><?php echo e($project->technicalAdvances->engineering_release); ?> %</b>
					</div>
					<p><span id="lower-text">LIBERACIÓN DE
							<br>INGENIERÍA</span></p>
				</li>

				<li class="timeline-item">
					<div class="timeline-badge primary">
						<b><?php echo e($project->technicalAdvances->work_progress); ?> %</b>
					</div>
					<p><span id="lower-text">AVANCE DE
							<br>TRABAJOS</span></p>
				</li>


				<li class="timeline-item">
					<div class="timeline-badge primary">
						<b><?php echo e($project->technicalAdvances->delivery_customer); ?> %</b>
					</div>
					<p><span id="lower-text">ENTREGA A
							<br>CLIENTE</span></p>
				</li>

				<li class="timeline-item select">
					<select class="select-css" onchange="window.location.href=this.value;">
						<option selected>RELACIONADOS</option>
						<?php $__currentLoopData = $project->affiliations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affiliation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e(url('/projects/advances/advance',['idProject' => $affiliation->id, 'typeproject' => $affiliation->project_type_id])); ?>"><?php echo e($affiliation->folio); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</li>
			</ul>
		</div>

		<!-- AVANCE ECONÓMICO -->
		<div style="display:inline-block;width:100%;">
			<ul class="timelines timelines-horizontale">
				<li class="timelines-item1">
					<button class="btn btn-sm btn-primary">AVANCE ECONÓMICO</button>
				</li>
				<li class="timelines-item1">
					<div class="timelines-badges primary">
						<b><?php echo e($project->economicAdvances->initial_advance_percentage); ?> %</b>
						<p> $ <?php echo e($project->economicAdvances->initial_advance_mount); ?></p>
					</div>
					<p1> <a href=""> <span id="lower-text1">ANTICIPO</span></a></p>
				</li>
				<li class="timelines-item1">
					<div class="timelines-badges primary">
						<b><?php echo e($project->economicAdvances->engineering_release_payment_percentage); ?> %</b>
						<p> $ <?php echo e($project->economicAdvances->engineering_release_payment_mount); ?></p>
					</div>
					<p><span id="lower-text1">PAGO POR LIBERACIÓN</span></p>
				</li>

				<li class="timelines-item1">
					<div class="timelines-badges primary">
						<b><?php echo e($project->economicAdvances->final_payment_percentage); ?> %</b>
						<p> $ <?php echo e($project->economicAdvances->final_payment_mount); ?></p>
					</div>
					<p><span id="lower-text1">PAGO FINAL PROYECTO</span></p>
				</li>

				<li class="timelines-item1">
					<button class="btn btn-sm btn-primary"> $ <?php echo e($project->total_amount); ?> <?php echo e($project->coin->code); ?></button>
				</li>
			</ul>
		</div>
	</div>
</section>
<?php echo $__env->make('client/projects/advances/modals/images', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('client/projects/advances/modals/offers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('client/projects/advances/modals/purchaseOrders', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('client/projects/advances/modals/minutas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<!-- <script src="/js/advance.js"></script> -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/client/projects/advances/advance.blade.php ENDPATH**/ ?>