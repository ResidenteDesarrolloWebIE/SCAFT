<div id="preloder">
    <div class="loader"></div>
</div>
<header class="encabezado">
    <nav class="navbar navbar-expand-sm  fixed-top" style="background-color:#19202C">
        <a href="<?php echo e(url('/home')); ?>" class="site-logo text-center">
            <img class="logo" src="<?php echo e(asset('images/logo-navigationBar.png')); ?>" alt="">
        </a>
        <button class="navbar-toggler navbar-toggler-right" style="background-color:gray" type="button" data-toggle="collapse" data-target="#navbarToggler">
            <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse offset-md-1" id="navbarToggler">
            <ul class="navbar-nav mr-auto">

                <?php if(Auth::user()->hasAnyRole(['Administrador','Ofertas','Ventas','Ingenieria','Manufactura','Servicio','Almacen','Finanzas', 'Lider', 'Consulta'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/home')); ?>">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('projects')); ?>">Lista de proyectos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('users')); ?>">Lista de Usuarios</a>
                    </li>
                <?php elseif(Auth::user()->hasAnyRole(['Cliente'])): ?>
                    <li class="nav-item">
                        <a class="nav-link " href="<?php echo e(url('/home')); ?>">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('projects/supplies')); ?>">Suministros</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('projects/services')); ?>"> Servicios</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link"> El rol asignado no existe</a>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="text-center">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="nameUser" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="text-transform: uppercase">
                        <?php echo e(Auth::user()->name); ?>

                    </button>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu1">
                        <a class="dropdown-item text-center" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                            <?php echo e(__('Cerrar sesión')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/layouts/partials/_navigationBar.blade.php ENDPATH**/ ?>