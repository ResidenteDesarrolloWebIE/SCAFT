<?php $__env->startSection('content'); ?>

<section class="gallery" style="margin-top: 20px">
	<?php echo $__env->make('layouts.partials._navigationBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<body>
		<header>
			<div>
				<h1></h1>
				<hr style='margin-top:-5px; margin-bottom: 30px' class="hr-text" />
			</div>
		</header>
		<div class="demo1">
			<ul class="galeria">
				<div class="row">
					<?php if($project->images->isEmpty()): ?>
					<div class="alert text-center row" role="alert">
						<strong>No hay imagenes para mostrar</strong>
					</div>
					<?php endif; ?>
					<?php $__currentLoopData = $project->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-3 text-center" style="margin-right:0px">
						<span>
							<span style="display: none"><?php echo e(setlocale(LC_TIME,'spanish')); ?></span>
							<?php echo e(strftime("%d de %B del %Y", strtotime(date("d M Y",strtotime($image->created_at))))); ?>

						</span>
						<li><a href="<?php echo e('#image'.explode('.', explode('_', $image->name)[1])[0]); ?>"><img src="<?php echo e(asset('storage/'.$image->path )); ?>"></a></li>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $project->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-3 text-center" style="margin-right: 0px">
						<span>
							<span style="display: none"><?php echo e(setlocale(LC_TIME,'spanish')); ?></span>
							<?php echo e(strftime("%d de %B del %Y", strtotime(date("d M Y",strtotime($image->created_at))))); ?>

						</span>
						<li><a href="<?php echo e('#image'.explode('.', explode('_', $image->name)[1])[0]); ?>"><img src="<?php echo e(asset('storage/'.$image->path )); ?>"></a></li>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
			</ul>
			<?php $__currentLoopData = $project->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<figure id="<?php echo e('image'.explode('.', explode('_', $image->name)[1])[0]); ?>" class="lbox bounce">
				<span><a href="<?php echo e('#image'. ( intval( explode('.', explode('_', $image->name)[1])[0])-1)); ?>" title='Anterior'><i class="fas fa-angle-left"></i></a></span>
				<img alt="" title="" src="<?php echo e(asset('storage/'.$image->path )); ?>" />
				<span id='right'><a href="<?php echo e('#image'. ( intval( explode('.', explode('_', $image->name)[1])[0])+1)); ?>" title='Siguiente'><i class="fas fa-angle-right"></i></a></span>
				<a title='Cerrar' href="#_"><i class="fas fa-times"></i></a>
				<h2>
					<span style="display: none"><?php echo e(setlocale(LC_TIME,'spanish')); ?></span>
					<?php echo e(strftime("%d de %B del %Y", strtotime(date("d M Y",strtotime($image->created_at))))); ?>

				</h2>
			</figure>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<link href="https://fonts.googleapis.com/css?family=Raleway:200,100,400" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous" />
		<link href="https://fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet" />
	</body>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/client/projects/advances/gallery.blade.php ENDPATH**/ ?>