<?php $__env->startSection('content'); ?>

<head>
    <link href="/css/projectlist.css" rel="stylesheet">
</head>

<?php $__env->startSection('content'); ?>
<section class="section-projects-admin py-2 text-xs-center">
    <div class="fondo">
        <?php echo $__env->make('layouts.partials._navigationBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container container-projects-admin">
            <div class="row table-responsive text-center projects-table">
                <h1 class="text-center">LISTA DE PROYECTOS</h1>
                <?php if( (Auth::user()->hasRole('Lider') && Auth::user()->hasRole('Ventas')) || Auth::user()->hasAnyRole(['Administrador','Ofertas','Ventas','Servicio'])): ?>
                <div class="offset-md-8 col-md-4 text-right" style="margin-bottom: 10px">
                    <a data-toggle="modal" data-target="#createProject">
                        <button id="btnProject" type="button" class="btn btn-dark">
                            Crear nuevo proyecto &nbsp;&nbsp;<i class="fas fa-plus"></i>
                        </button>
                    </a>
                </div>
                <?php endif; ?>
                <table class="table text-center table-sm-responsive display nowrap" id="tableProjects">
                    <thead style="background-color: #252b37">
                        <tr>
                            <th> Id</th>
                            <th> Folio</th>
                            <th> Status</th>
                            <th class="not-sort"> Tipo</th>
                            <th> Nombre</th>
                            <th class="not-sort"> Descripcion</th>
                            <th> Cliente</th>
                            <th> Codigo</th>
                            <th class="not-sort"> Oferta</th>
                            <th class="not-sort"> Orden de compra</th>
                            <th class="col-md-3 not-sort">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <?php if(Auth::user()->hasAnyRole(['Consulta'])): ?>
                            <td><?php echo e($project->id); ?></td>
                            <td><?php echo e($project->folio); ?></td>
                            <td><?php echo e($project->status); ?></td>
                            <td><?php echo e($project->type->name); ?></td>
                            <td><?php echo e($project->name); ?></td>
                            <td><?php echo e($project->description); ?></td>
                            <td><?php echo e($project->customer->name); ?></td>
                            <td><?php echo e($project->customer->code); ?></td>
                            <td>
                                <?php if(!is_null($project->offer)): ?>
                                <a href="<?php echo e(url('/projects/offers/download',$project->id)); ?>">
                                    <button type="button" class="btn btn-primary" title="Descargar oferta"><i class="fas fa-download"></i></button>
                                </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(!is_null($project->purchaseOrder)): ?>
                                <a href="<?php echo e(url('/projects/purchaseOrders/download',$project->id)); ?>">
                                    <button type="button" class="btn btn-primary" title="Descargar orden de compra"><i class="fas fa-download"></i></button>
                                </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if( (Auth::user()->hasRole('Lider') && Auth::user()->hasRole('Ventas')) || Auth::user()->hasAnyRole(['Administrador','Ofertas','Ventas','Servicio'])): ?>
                                    <a data-toggle="modal" data-target="#editProject">
                                        
                                        <button type="button" class="btn btn-primary" title="Editar Proyecto" onclick='inicializeEditProject(<?php echo e($project); ?>)'><i class="fas fa-edit"></i></button>
                                    </a>
                                <?php endif; ?>
                                <a data-toggle="modal" data-target="#economicAdvanceProject">
                                    <button type="button" class="btn btn-dark" title="Editar avance economico" onclick='initilizeEconomicAdvance(<?php echo e($project); ?>)'><i class="fas fa-edit" style="color:#fff"></i><i class="fas fa-dollar-sign" style="color:#fff"></i></button>
                                </a>
                                <a data-toggle="modal" data-target="#technicalAdvanceProject">
                                    <button type="button" class="btn btn-primary" title="Editar avance tecnico" onclick='initializeTechnicalAdvance(<?php echo e($project); ?>)'><i class="fas fa-edit" style="color:#fff"></i><i class="fas fa-wrench" style="color:#fff"></i></button>
                                </a>
                                <a href="<?php echo e(url('minutas',$project)); ?>">
                                    <button type="button" class="btn btn-dark" title="Minutas"><i class="fas fa-file-alt"></i></button>
                                </a>
                                <?php if(Auth::user()->hasAnyRole(['Administrador','Manufactura','Servicio'])): ?>
                                <a data-toggle="modal" data-target="#imagesProject" onclick='imagesProject( <?php echo e($project); ?>)'>
                                    <button type="button" class="btn btn-primary" title="Agregar imagenes"><i class="fas fa-images"></i></button>
                                </a>
                                <?php endif; ?>
                            </td>
                            <?php else: ?>
                            <td colspan="11">
                                Sin registros por mostrar. No tiene el rol de consulta asignado.
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No hay datos</p>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin/projects/modals/create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(!$projects->isEmpty()): ?>
        <?php echo $__env->make('admin/projects/modals/edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin/projects/modals/economicAdvanceEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin/projects/modals/technicalAdvanceEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin/projects/modals/images', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('admin/projects/modals/create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/admin/projects/projects.blade.php ENDPATH**/ ?>