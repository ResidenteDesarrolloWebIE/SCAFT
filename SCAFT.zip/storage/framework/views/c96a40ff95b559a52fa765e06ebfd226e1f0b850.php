<footer class="footer   py-2 text-xs-center">
  <div class="container text-center">
    <small>Copyright © All rights reserved 2020 - Integración de Energía.</small><br>
    <small><a href="mailto:enlace@integracion-energia.com">enlace@integracion-energia.com  </a> </small>
    <h6>Rev. 1</h6>
  </div>
</footer><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/layouts/partials/_footer.blade.php ENDPATH**/ ?>