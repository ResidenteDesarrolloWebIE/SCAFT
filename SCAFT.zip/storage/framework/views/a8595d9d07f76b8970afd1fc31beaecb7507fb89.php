<?php $__env->startSection('content'); ?>

<section class="section-projects py-2 text-xs-center">
    <?php echo $__env->make('layouts.partials._navigationBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container container-projects">
        <h2 class="text-center">SUMINISTROS SOLICITADOS</h2><br>
        <div class="row center-content">
            <?php if($projects->isEmpty()): ?>
            <div class="alert text-center col-md-8" role="alert">
                <strong>No ha solicitado suministros</strong>
            </div>
            <?php endif; ?>
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 list-projects">
                <div class="do-item do-item-circle do-circle item-projects">
                    <img src="<?php echo e(asset('images/supply-supplies.png')); ?>" class="do-item do-circle do-item-circle-back">
                    <div class="do-info-wrap do-circle">
                        <div class="do-info">
                            <div class="do-info-front do-circle">
                                <h1 class="t-stroke text-center"><?php echo e($project->folio); ?></h1>
                            </div>
                            <div class="do-info-back do-circle text-center">
                                <h3 class="text-info">
                                    <strong class="decription-color">
                                        <?php echo e($project->description); ?>

                                    </strong>
                                </h3>
                                <div class="details-projects">
                                    Suministro / <?php echo e($project->status); ?>

                                    <br /> <?php echo e(date("d M Y",strtotime($project->created_at))); ?>

                                    <div class="buttons-projects">
                                        <a href="<?php echo e(url('/projects/advances/advance',['idProject' => $project->id, 'typeproject' => 1])); ?>"> <!-- Suministros tien e el id 1 -->
                                            <button class="backgroud-icon">
                                                <span data-toggle="tooltip" data-placement="bottom" ><!-- title="Avance del proyecto!" -->
                                                <i class="far fa-images" style="color:white;"></i><i class="fas fa-dollar-sign" style="color:white;"></i> DETALLES
                                                </span>
                                            </button>
                                        </a>
                                        <!-- <a href="<?php echo e(url('/projects/advances/gallery',['idProject' => $project->id, 'typeproject' => 1])); ?>">
                                            <button class="backgroud-icon" id="btnGallerySupply">
                                                <span data-toggle="tooltip" data-placement="bottom" title="Galeria!">
                                                    <i class="far fa-images" style="color:white;"></i>
                                                </span>
                                            </button>
                                        </a> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SI0003\Desktop\SCAFT\resources\views/client/projects/supplies.blade.php ENDPATH**/ ?>