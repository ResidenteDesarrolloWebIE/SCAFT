<?php

namespace App\Models\Synchronization;

use Illuminate\Database\Eloquent\Model;

class AdmDatabaseSync extends Model
{
    //const UPDATED_AT = 'date_of_last_update';
}
