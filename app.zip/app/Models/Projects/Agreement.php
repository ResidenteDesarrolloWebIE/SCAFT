<?php

namespace App\Models\Projects;

use Illuminate\Database\Eloquent\Model;

class Agreement extends Model
{
    //
}
